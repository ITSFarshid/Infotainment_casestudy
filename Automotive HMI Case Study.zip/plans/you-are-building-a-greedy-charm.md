# Plan: single case-study page — one automotive Home for two display widths

## Context
The user wants one long-form editorial case study (10–15 min read) built from the supplied Markdown. No navbar, no portfolio parts, and the word "ATLAS" must not appear anywhere. The project is already a React + Vite + Tailwind v4 app (`src/App.tsx` is empty). Per project rules I'll extend that app instead of adding a plain index.html.

## Assets (already in `src/imports/`)
- `image.png` = final 1920 × 720 screen. `image-1.png` = final 2880 × 720 screen.
- `ChatGPT_Image_…png` = one lo-fi sheet holding all 4 concepts. **Its header says "ATLAS"**, so I will never show the whole image. Each concept is shown as its own crop (CSS wrapper with fixed aspect ratio, `object-position` set per band). That gives four separate figures and the title stays hidden. The lightbox also opens the crop, not the full sheet.
- OEM research images (received): attachments go to `src/assets/research/` via `figma attachments get <id> --dest`:
  - `d9de82cf` → `vw-id7.png` (VW ID.7)
  - `f34648fe` → `bmw-os85.png` (BMW OS 8.5 QuickSelect)
  - `96ae7ca9` → `mercedes-hyperscreen.png` (MBUX Hyperscreen)
  - Hyundai has no image, so it gets only its pattern diagram and the note "Source: Hyundai split-screen documentation". No placeholder image.
  These are shown at supporting size, with captions taken from the Markdown ("Official … image"). I make no claims about them beyond what the Markdown says.

## Files
- `src/App.tsx`: puts the page sections together.
- `src/components/casestudy/*.tsx`: Section, Figure (with lightbox), Diagrams (inline SVG/CSS), Matrix.
- `src/index.css`: Geist via Google Fonts `@import` (placed first), tokens (warm off-white #FAFAF8, ink #111, muted #6B6B66, rule #E4E3DF, one accent: the screenshots' cyan #3BB8E8, used only for the chosen direction and the reach band).

## Page structure (copy stays close to the Markdown)
Opening (title, display specs, 2 paragraphs, the problem statement shown once) → 01 Constraint (SVG width bars, +960) → 02 Scope (2-column compact list + assumptions) → 03 Research (VW / BMW / Hyundai / Mercedes, each with "What I looked at → / What I took →" plus a pattern diagram; then the 3 surviving rules) → 04 Home IA (tier diagram) → 05 Baseline (dimension diagram 88 / 824 / 448 / 32) → 06 Explorations A–D (cropped lo-fi + short paragraph; D gets an accent rule and a "Chosen direction" label; plain language, no "Unfold"), then a qualitative Strong/Medium/Weak matrix labeled "qualitative judgement, not measured" → 07 Chosen system (1920 vs 2880 block diagram at the same scale, then both final screenshots) → 08 "More visible did not mean more reachable." (driver-reach diagram) → 09 Bringing content nearer (3 frames: default / select Phone / swipe; labeled "Design hypothesis — needs ergonomic and user validation") → 10 Content logic (short) → 11 Reusable depth (card → 448×544 panel mapping) → 12 Final result (large screenshots + Same/Changes) → 13 What I'd test next (Markdown questions, stated as untested) → 14 Closing.

Grid: 1200px max width, 720px reading column, figures up to 1200px, collapses on mobile. Type: title clamp(44–76px), H2 36px, body 18/1.6, captions 13px. No shadows, no gradients, no animation. The only JS is a small React lightbox.

## Verification
Run `grep -ri atlas src` (expect it to match only the image filename, never visible text). Check the preview once for layout.
