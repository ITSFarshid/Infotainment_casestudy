import type React from 'react'
// Simple line diagrams. Screen units are real pixels divided by 4.
const INK = '#171717'
const MUTED = '#666666'
const RULE = '#d4d4d4'
const FILL = '#fafafa'
const ACCENT = '#0a72ef'

const S = 0.25
const RAIL_X = 16, RAIL_W = 88, MAP_X = 120, MAP_W = 824, CARD_W = 448, GAP = 32, TOP = 88, H = 544
const cardX = (i: number) => MAP_X + MAP_W + GAP + i * (CARD_W + GAP)

type Card = { label: string; ghost?: boolean; accent?: boolean }

export function Screen({
  width,
  cards,
  y = 0,
  label,
  boundary,
  showDims,
}: {
  width: 1920 | 2880
  cards: Card[]
  y?: number
  label?: string
  boundary?: boolean
  showDims?: boolean
}) {
  const w = width * S
  const h = 720 * S
  return (
    <g transform={`translate(0 ${y})`}>
      {label && (
        <text x={0} y={-10} fontSize={11} fill={INK} letterSpacing=".04em">
          {label}
        </text>
      )}
      <rect x={0.5} y={0.5} width={w} height={h} fill="#fff" stroke={INK} strokeWidth={1} rx={3} />
      <rect x={RAIL_X * S} y={TOP * S} width={RAIL_W * S} height={H * S} fill="none" stroke={RULE} />
      <rect x={MAP_X * S} y={TOP * S} width={MAP_W * S} height={H * S} fill={FILL} stroke={INK} />
      <text x={(MAP_X + MAP_W / 2) * S} y={(TOP + H / 2) * S + 4} fontSize={11} textAnchor="middle" fill={INK}>
        MAP
      </text>
      {cards.map((c, i) => {
        const x = cardX(i) * S
        const visible = cardX(i) + CARD_W <= width
        const stroke = c.accent ? ACCENT : visible ? INK : RULE
        return (
          <g key={i}>
            <rect
              x={x}
              y={TOP * S}
              width={CARD_W * S}
              height={H * S}
              fill={c.accent ? '#e4f3fa' : '#fff'}
              stroke={stroke}
              strokeDasharray={visible ? undefined : '3 3'}
            />
            <text
              x={x + (CARD_W * S) / 2}
              y={(TOP + H / 2) * S + 4}
              fontSize={10}
              textAnchor="middle"
              fill={visible ? (c.accent ? ACCENT : INK) : MUTED}
            >
              {c.label.toUpperCase()}
            </text>
          </g>
        )
      })}
      {boundary && (
        <>
          <line x1={1920 * S} x2={1920 * S} y1={-6} y2={h + 6} stroke={ACCENT} strokeDasharray="4 3" />
        </>
      )}
      {showDims && (
        <g fontSize={10} fill={MUTED}>
          <Dim x1={RAIL_X * S} x2={(RAIL_X + RAIL_W) * S} y={h + 18} label="88" />
          <Dim x1={MAP_X * S} x2={(MAP_X + MAP_W) * S} y={h + 18} label="824 × 544" />
          <Dim x1={cardX(0) * S} x2={(cardX(0) + CARD_W) * S} y={h + 18} label="448 × 544" />
          <Dim x1={(MAP_X + MAP_W) * S} x2={cardX(0) * S} y={h + 44} label="32" />
          <Dim x1={cardX(1) * S} x2={(cardX(1) + CARD_W) * S} y={h + 18} label="448 × 544" />
        </g>
      )}
    </g>
  )
}

function Dim({ x1, x2, y, label }: { x1: number; x2: number; y: number; label: string }) {
  return (
    <g>
      <line x1={x1} x2={x2} y1={y} y2={y} stroke={MUTED} />
      <line x1={x1} x2={x1} y1={y - 4} y2={y + 4} stroke={MUTED} />
      <line x1={x2} x2={x2} y1={y - 4} y2={y + 4} stroke={MUTED} />
      <text x={(x1 + x2) / 2} y={y + 15} textAnchor="middle" fontSize={10} fill={MUTED}>
        {label}
      </text>
    </g>
  )
}

export function WidthDiagram() {
  return (
    <svg viewBox="-2 -24 724 250" role="img" aria-label="1920 by 720 display compared with 2880 by 720 display">
      <text x={0} y={-10} fontSize={11} fill={INK}>1920 × 720</text>
      <rect x={0.5} y={0.5} width={480} height={60} fill="#fff" stroke={INK} rx={3} />
      <text x={0} y={102} fontSize={11} fill={INK}>2880 × 720</text>
      <rect x={0.5} y={112.5} width={720} height={60} fill="#fff" stroke={INK} rx={3} />
      <rect x={480} y={113} width={240} height={59} fill="#e4f3fa" />
      <line x1={480} x2={480} y1={-4} y2={180} stroke={ACCENT} strokeDasharray="4 3" />
      <Dim x1={480} x2={720} y={192} label="+960 px" />
      <text x={240} y={36} textAnchor="middle" fontSize={10} fill={MUTED}>same component dimensions</text>
      <text x={600} y={148} textAnchor="middle" fontSize={10} fill={ACCENT}>what is this width for?</text>
    </svg>
  )
}

export function BaselineDiagram() {
  return (
    <svg viewBox="-2 -24 484 260" role="img" aria-label="1920 baseline geometry">
      <Screen width={1920} cards={[{ label: 'Media' }, { label: 'Journey' }]} label="1920 × 720 — FROZEN BASELINE" showDims />
    </svg>
  )
}

const COLLECTION: Card[] = [{ label: 'Media' }, { label: 'Journey' }, { label: 'Phone' }, { label: 'Ahead' }]

export function SystemDiagram() {
  // Off-screen cards sit outside the 1920 frame, so they get their own label instead of overlapping text.
  const offX = cardX(2) * S
  return (
    <svg viewBox="-2 -24 724 450" role="img" aria-label="1920 shows two cards, 2880 shows four cards of the same collection">
      <Screen width={1920} cards={COLLECTION} label="1920 — SMALLER WINDOW INTO THE SAME COLLECTION" />
      <text x={offX} y={(TOP - 16) * S} fontSize={9} fill={MUTED} letterSpacing=".04em">OFF-SCREEN →</text>
      <Screen width={2880} cards={COLLECTION} y={240} label="2880 — WIDER WINDOW INTO THE SAME COLLECTION" />
    </svg>
  )
}

export function ReachDiagram() {
  // Labels row, then the screen. The reach band covers exactly the 1920-wide driver side.
  const y = 64
  const h = 720 * S
  return (
    <svg viewBox="-2 0 724 310" role="img" aria-label="Driver interaction area compared with extended visible area">
      <g transform="translate(8 6)">
        <circle cx={7} cy={7} r={6} fill="none" stroke={INK} />
        <path d="M-2 26 Q7 14 16 26" fill="none" stroke={INK} />
        <text x={24} y={18} fontSize={10} fill={INK}>DRIVER</text>
      </g>
      <rect x={0} y={y - 10} width={1920 * S} height={h + 20} fill="#e4f3fa" />
      <text x={0} y={y - 18} fontSize={10} fill={ACCENT}>DRIVER-SIDE INTERACTION AREA — ASSUMED, NOT MEASURED</text>
      <text x={1920 * S + 10} y={y - 18} fontSize={10} fill={MUTED}>EXTENDED VISIBLE AREA</text>
      <Screen width={2880} cards={COLLECTION} y={y} boundary />
      <g stroke={INK} fill="none">
        <line x1={600} x2={600} y1={y + h + 6} y2={y + h + 34} />
        <path d={`M596 ${y + h + 14} L600 ${y + h + 6} L604 ${y + h + 14}`} />
      </g>
      <text x={600} y={y + h + 50} textAnchor="middle" fontSize={10} fill={INK}>visible, but farther away</text>
    </svg>
  )
}

export function MoveFrames() {
  const frames: { label: string; cards: Card[]; note: string }[] = [
    { label: 'DEFAULT', cards: COLLECTION, note: 'Media + Journey nearest to the map' },
    {
      label: 'SELECT “PHONE” IN THE FIXED SELECTOR',
      cards: [{ label: 'Phone', accent: true }, { label: 'Ahead' }, { label: 'Media' }, { label: 'Journey' }],
      note: 'the collection moves; Phone lands beside the map',
    },
  ]
  return (
    <div className="grid gap-12 lg:grid-cols-2">
      {frames.map((f) => (
        <figure key={f.label} className="m-0">
          <p className="eyebrow mb-3">{f.label}</p>
          <div className="grid gap-5">
            <svg viewBox="-2 -4 484 190">
              <text x={0} y={-8} fontSize={10} fill={MUTED} />
              <Screen width={1920} cards={f.cards} />
            </svg>
            <svg viewBox="-2 -4 724 190">
              <Screen width={2880} cards={f.cards} />
            </svg>
          </div>
          <figcaption className="caption">
            <b>1920 above, 2880 below.</b> {f.note}.
          </figcaption>
        </figure>
      ))}
    </div>
  )
}

/* Small research pattern sketches */
export function Pattern({ kind }: { kind: 'vw' | 'bmw' | 'hyundai' | 'mercedes' }) {
  const box = { fill: 'none', stroke: INK }
  const t = (x: number, y: number, s: string, c = MUTED, a: 'start' | 'middle' = 'middle') => (
    <text x={x} y={y} fontSize={9} fill={c} textAnchor={a}>
      {s}
    </text>
  )
  return (
    <svg viewBox="0 0 240 120" className="w-full" role="img" aria-label={`${kind} pattern diagram`}>
      {kind === 'vw' && (
        <>
          <rect x={20} y={8} width={200} height={14} {...box} stroke={RULE} />
          {t(120, 18, 'persistent shortcuts')}
          <rect x={20} y={28} width={200} height={62} fill={FILL} stroke={INK} />
          {t(120, 63, 'MAIN WORKSPACE', INK)}
          <rect x={20} y={96} width={200} height={14} {...box} stroke={RULE} />
          {t(120, 106, 'persistent controls (climate)')}
        </>
      )}
      {kind === 'bmw' && (
        <>
          <rect x={20} y={14} width={200} height={92} {...box} />
          <rect x={26} y={20} width={64} height={80} fill="#fff" stroke={INK} />
          {t(58, 62, 'widget', INK)}
          <rect x={96} y={20} width={118} height={80} fill={FILL} stroke={RULE} />
          {t(155, 62, 'MAP CONTEXT', INK)}
        </>
      )}
      {kind === 'hyundai' && (
        <>
          <rect x={20} y={14} width={200} height={92} {...box} />
          <rect x={26} y={20} width={120} height={80} fill={FILL} stroke={INK} />
          {t(86, 62, 'PRIMARY STAYS', INK)}
          <rect x={152} y={20} width={62} height={80} fill="#fff" stroke={INK} strokeDasharray="3 3" />
          {t(183, 58, 'secondary')}
          {t(183, 70, 'changes')}
        </>
      )}
      {kind === 'mercedes' && (
        <>
          <rect x={6} y={30} width={228} height={60} {...box} />
          <rect x={12} y={36} width={58} height={48} fill="#fff" stroke={RULE} />
          {t(41, 63, 'cluster')}
          <rect x={76} y={36} width={84} height={48} fill={FILL} stroke={INK} />
          {t(118, 63, 'CENTRE', INK)}
          <rect x={166} y={36} width={62} height={48} fill="#fff" stroke={INK} strokeDasharray="3 3" />
          {t(197, 63, 'passenger')}
          {t(120, 110, 'one surface, different zones')}
        </>
      )}
    </svg>
  )
}

/* Exploration sketches — 1920 above, 2880 below, same scale */
type Box = { x: number; w: number; y?: number; h?: number; label: string; style?: 'card' | 'quiet' | 'zone' | 'accent' }

function Frame({ width, boxes, y, label, extra }: { width: number; boxes: Box[]; y: number; label: string; extra?: React.ReactNode }) {
  return (
    <g transform={`translate(0 ${y})`}>
      <text x={0} y={-10} fontSize={11} fill={INK}>{label}</text>
      <rect x={0.5} y={0.5} width={width * S} height={720 * S} fill="#fff" stroke={INK} rx={3} />
      <rect x={RAIL_X * S} y={TOP * S} width={RAIL_W * S} height={H * S} fill="none" stroke={RULE} />
      <rect x={MAP_X * S} y={TOP * S} width={MAP_W * S} height={H * S} fill={FILL} stroke={INK} />
      <text x={(MAP_X + MAP_W / 2) * S} y={(TOP + H / 2) * S + 4} fontSize={11} textAnchor="middle" fill={INK}>MAP</text>
      {boxes.map((b, i) => {
        const by = (b.y ?? TOP) * S
        const bh = (b.h ?? H) * S
        const st = b.style ?? 'card'
        return (
          <g key={i}>
            <rect
              x={b.x * S}
              y={by}
              width={b.w * S}
              height={bh}
              fill={st === 'quiet' ? FILL : st === 'accent' ? '#e4f3fa' : '#fff'}
              stroke={st === 'quiet' ? RULE : st === 'accent' ? ACCENT : INK}
              strokeDasharray={st === 'quiet' ? '3 3' : undefined}
            />
            <text x={(b.x + b.w / 2) * S} y={by + bh / 2 + 4} fontSize={10} textAnchor="middle" fill={st === 'quiet' ? MUTED : st === 'accent' ? ACCENT : INK}>
              {b.label.toUpperCase()}
            </text>
          </g>
        )
      })}
      {extra}
    </g>
  )
}

const c = (i: number, label: string, style?: Box['style']): Box => ({ x: cardX(i), w: CARD_W, label, style })
const BASE = [c(0, 'Card 1'), c(1, 'Card 2')]

function Arrow({ x1, x2, y }: { x1: number; x2: number; y: number }) {
  return (
    <g stroke={MUTED} fill="none">
      <line x1={x1} x2={x2} y1={y} y2={y} />
      <path d={`M${x1 + 5} ${y - 4} L${x1} ${y} L${x1 + 5} ${y + 4}`} />
      <path d={`M${x2 - 5} ${y - 4} L${x2} ${y} L${x2 - 5} ${y + 4}`} />
    </g>
  )
}

export function ConceptSketch({ kind }: { kind: 'A' | 'B' | 'C' | 'D' }) {
  let wide: Box[] = []
  let extra: React.ReactNode = null
  const mid = (TOP + H / 2) * S
  if (kind === 'A') {
    wide = [...BASE, { x: 1920, w: 2880 - 1920 - 16, label: 'quiet area — minimal content', style: 'quiet' }]
  }
  if (kind === 'B') {
    wide = [{ x: 1340, w: CARD_W, label: 'Card 1' }, { x: 2390, w: CARD_W, label: 'Card 2' }]
    extra = (
      <>
        <Arrow x1={(MAP_X + MAP_W) * S + 8} x2={1340 * S - 8} y={mid} />
        <Arrow x1={(1340 + CARD_W) * S + 8} x2={2390 * S - 8} y={mid} />
      </>
    )
  }
  if (kind === 'C') {
    const zx = 1936
    const zw = 2880 - zx - 16
    wide = [
      ...BASE,
      { x: zx, w: zw, y: TOP, h: 256, label: 'Quick actions' },
      { x: zx, w: zw, y: TOP + 288, h: 256, label: 'Trip info' },
    ]
    extra = (
      <g fontSize={9} fill={MUTED}>
        <line x1={(MAP_X + MAP_W + 16) * S} x2={(MAP_X + MAP_W + 16) * S} y1={8} y2={172} stroke={RULE} strokeDasharray="3 3" />
        <line x1={1928 * S} x2={1928 * S} y1={8} y2={172} stroke={RULE} strokeDasharray="3 3" />
        <text x={(MAP_X + MAP_W / 2) * S} y={14} textAnchor="middle">DRIVER ZONE</text>
        <text x={1432 * S} y={14} textAnchor="middle">PRIMARY ZONE</text>
        <text x={(zx + zw / 2) * S} y={14} textAnchor="middle">SECONDARY ZONE — NEW LAYOUT</text>
      </g>
    )
  }
  if (kind === 'D') {
    wide = [c(0, 'Card 1'), c(1, 'Card 2'), c(2, 'Card 3', 'accent'), c(3, 'Card 4', 'accent')]
    extra = (
      <g>
        <line x1={1920 * S} x2={1920 * S} y1={-4} y2={184} stroke={ACCENT} strokeDasharray="4 3" />
        {[0, 1, 2, 3].map((i) => (
          <circle key={i} cx={(1400 + i * 40) * S} cy={168} r={2.5} fill={i < 2 ? INK : 'none'} stroke={INK} />
        ))}
        <text x={(1400 + 180) * S} y={171} fontSize={9} fill={MUTED}>selector — bring a card nearer</text>
      </g>
    )
  }
  const narrowExtra =
    kind === 'D' ? (
      <text x={492} y={mid + 4} fontSize={10} fill={MUTED}>→ Card 3, 4</text>
    ) : null
  return (
    <svg viewBox="-2 -24 724 440" role="img" aria-label={`Exploration ${kind}: 1920 and 2880`}>
      <Frame width={1920} boxes={BASE} y={0} label="1920" extra={narrowExtra} />
      <Frame width={2880} boxes={wide} y={230} label="2880" extra={extra} />
    </svg>
  )
}
