import { useEffect, useRef, useState, type ReactNode } from 'react'
import final1920 from './imports/image.png'
import final2880 from './imports/image-1.png'
import {
  BaselineDiagram,
  ConceptSketch,
  MoveFrames,
  Pattern,
  ReachDiagram,
  SystemDiagram,
  WidthDiagram,
} from './components/Diagrams'

// Set this to the live prototype URL when it is ready.
const DEMO_URL = 'https://atlas-home-tawny.vercel.app/final-proposal/prototype.html'
const SCREEN_URL = 'https://atlas-home-tawny.vercel.app/final-proposal/prototype-screen.html'

type Zoom = { src: string; alt: string } | null
let openZoom: (z: Zoom) => void = () => {}

function Section({ n, label, title, children }: { n: string; label: string; title: string; children: ReactNode }) {
  return (
    <section className="section">
      <header className="section-head">
        <span className="section-num">{n}</span>
        <div>
          <span className="section-label">{label}</span>
          <h2 className="section-title">{title}</h2>
        </div>
      </header>
      {children}
    </section>
  )
}

function Shot({ src, alt, caption }: { src: string; alt: string; caption?: ReactNode }) {
  return (
    <figure className="m-0">
      <button className="fig-btn" onClick={() => openZoom({ src, alt })} aria-label={`Enlarge: ${alt}`}>
        <img className="shot" src={src} alt={alt} />
      </button>
      {caption && <figcaption className="caption">{caption}</figcaption>}
    </figure>
  )
}

function ResearchImage({ src, alt }: { src: string; alt: string }) {
  const [failed, setFailed] = useState(false)
  if (failed)
    return (
      <div className="crop flex aspect-[16/10] items-center justify-center p-6 text-center caption">
        Image placeholder — {alt}
      </div>
    )
  return (
    <button className="fig-btn" onClick={() => openZoom({ src, alt })} aria-label={`Enlarge: ${alt}`}>
      <img src={src} alt={alt} onError={() => setFailed(true)} className="aspect-[16/10] w-full rounded bg-[#0b0c0e] object-contain" />
    </button>
  )
}

const research = [
  {
    name: 'Volkswagen',
    kind: 'vw' as const,
    img: '/research/vw-id7.png',
    caption: 'Volkswagen ID.7. I used the separation between persistent controls and the main workspace as an IA reference. Official Volkswagen image.',
    looked: 'Persistent controls and shortcuts kept outside the main workspace.',
    took: 'A function can be important without needing its own large card. Climate needs quick access, but it does not need to compete with Navigation or Media for permanent Home space.',
  },
  {
    name: 'BMW',
    kind: 'bmw' as const,
    img: '/research/bmw-os85.png',
    caption: 'BMW Operating System 8.5 with QuickSelect. The useful pattern here was the map-first Home and direct access around it. Official BMW image.',
    looked: 'A map-oriented Home where secondary functions sit next to the driving context instead of replacing it.',
    took: 'Navigation as the stable primary surface, with the other domains as a collection beside it.',
  },
  {
    name: 'Hyundai',
    kind: 'hyundai' as const,
    img: '/research/hyundai-split-screen.gif',
    caption: 'Hyundai ccNC split screen: swiping opens a secondary region while the map stays. From the official Hyundai owner web manual.',
    looked: 'Split-screen logic: a primary task stays visible while a secondary region changes beside it.',
    took: "The system can keep one main context while showing more content next to it. I did not copy Hyundai's layout or assume its components behave like mine.",
  },
  {
    name: 'Mercedes-Benz',
    kind: 'mercedes' as const,
    img: '/research/mercedes-hyperscreen.png',
    caption: 'Mercedes-Benz MBUX Hyperscreen. A reference for functional zoning across a very wide surface, not a direct layout model. Official Mercedes-Benz source.',
    looked: 'Zero-layer: top-level space used to surface relevant information, not as empty room to fill.',
    took: 'A wide surface does not have to behave like one even canvas.',
  },
]

const concepts = [
  {
    id: 'A',
    title: 'Quiet extension',
    kind: 'A' as const,
    text: 'Keep the layout compact and leave the rest quiet. This was the safest option. It preserved the driver-side structure and needed almost no new logic, but the wide display had no real purpose. It looked like unused hardware rather than a deliberate second configuration.',
    verdict: 'Not continued',
  },
  {
    id: 'B',
    title: 'Spacing expansion',
    kind: 'B' as const,
    text: 'Increase the spacing. This technically used the extra width while keeping component sizes. I rejected it quickly because it created more distance without creating more value. The screen became wider, but the experience did not become better.',
    verdict: 'Rejected',
  },
  {
    id: 'C',
    title: 'Recomposed wide layout',
    kind: 'C' as const,
    text: 'Recompose the whole wide layout into zones. This gave me more freedom and produced some cleaner-looking wide compositions. The problem was that it weakened the reuse argument. I was effectively designing a second dashboard with the same cards.',
    verdict: 'Rejected',
  },
]

type Mark = 'Strong' | 'Medium' | 'Weak' | 'Low' | 'High' | 'None'
const matrixCols = ['Component reuse', 'Preserves driver-side core', 'Gives extra width a purpose', 'New layout logic introduced', 'Driver reach concern']
const matrix: { name: string; marks: Mark[]; chosen?: boolean }[] = [
  { name: 'A — Quiet extension', marks: ['Strong', 'Strong', 'Weak', 'None', 'Low'] },
  { name: 'B — Spacing expansion', marks: ['Strong', 'Medium', 'Weak', 'Low', 'High'] },
  { name: 'C — Recomposed layout', marks: ['Weak', 'Medium', 'Strong', 'High', 'Medium'] },
  { name: 'D — Reveal more of the collection', marks: ['Strong', 'Strong', 'Strong', 'Low', 'Medium'], chosen: true },
]
const dots: Record<Mark, number> = { Strong: 3, High: 3, Medium: 2, Weak: 1, Low: 1, None: 0 }

function ScaledScreen({ width }: { width: 1920 | 2880 }) {
  const ref = useRef<HTMLDivElement>(null)
  const [scale, setScale] = useState(0)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const ro = new ResizeObserver(() => setScale(el.clientWidth / width))
    ro.observe(el)
    return () => ro.disconnect()
  }, [width])
  return (
    <div ref={ref} className="relative w-full overflow-hidden rounded-[12px] bg-[#080808] shadow-[var(--ring)]" style={{ aspectRatio: `${width} / 720` }}>
      {scale > 0 && (
        <iframe
          key={width}
          src={`${SCREEN_URL}?width=${width}`}
          title={`Interactive Home prototype at ${width} × 720`}
          className="absolute left-0 top-0 origin-top-left border-0"
          style={{ width, height: 720, transform: `scale(${scale})` }}
        />
      )}
    </div>
  )
}

function LiveDemo() {
  const [width, setWidth] = useState<1920 | 2880>(2880)
  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
        <div className="inline-flex rounded-[8px] p-[3px] shadow-[var(--ring)]" role="group" aria-label="Display width">
          {([1920, 2880] as const).map((w) => (
            <button
              key={w}
              onClick={() => setWidth(w)}
              aria-pressed={width === w}
              className={`rounded-[6px] px-3 py-1.5 font-[family-name:var(--mono)] text-[13px] font-medium ${width === w ? 'bg-[var(--ink)] text-white' : 'text-[var(--muted)] hover:text-[var(--ink)]'}`}
            >
              {w} × 720
            </button>
          ))}
        </div>
        <a href={DEMO_URL} target="_blank" rel="noreferrer" className="text-[14px] font-medium text-[var(--ink)] underline underline-offset-4 hover:text-[var(--accent)]">
          Open full screen ↗
        </a>
      </div>
      <ScaledScreen width={width} />
      <p className="caption">Live prototype. Try the selector under the map. Opening it full screen gives you the real pixel size.</p>
    </div>
  )
}

function MarkCell({ m }: { m: Mark }) {
  return (
    <span className="inline-flex items-center gap-2">
      <span className="inline-flex gap-[3px]" aria-hidden>
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="h-[7px] w-[7px] rounded-full"
            style={{ background: i < dots[m] ? 'var(--ink)' : 'transparent', border: '1px solid var(--ink)' }}
          />
        ))}
      </span>
      <span className="text-[13px] text-[var(--ink-2)]">{m}</span>
    </span>
  )
}

export default function App() {
  const [zoom, setZoom] = useState<Zoom>(null)
  openZoom = setZoom
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && setZoom(null)
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [])

  return (
    <main className="page">
      {/* Opening */}
      <header className="pt-24 pb-6 md:pt-32">
        <p className="eyebrow mb-8">Case study — Automotive HMI</p>
        <h1 className="title">Designing one automotive Home for two display widths</h1>
        <div className="mt-10 flex flex-wrap gap-x-12 gap-y-4 border-t border-[var(--rule)] pt-5">
          <div>
            <p className="eyebrow mb-1">Designer</p>
            <p className="text-[17px]">Farshid Yaghoubi</p>
          </div>
          <div>
            <p className="eyebrow mb-1">For</p>
            <p className="text-[17px]">ZeroB</p>
          </div>
          <div>
            <p className="eyebrow mb-1">Displays</p>
            <p className="text-[17px]">1920 × 720 → 2880 × 720</p>
          </div>
          <div>
            <p className="eyebrow mb-1">Constraint</p>
            <p className="text-[17px]">Same component dimensions</p>
          </div>
          <div>
            <p className="eyebrow mb-1">Outcome</p>
            <p className="text-[17px]">One Home system using the same component sizes on both displays</p>
          </div>
        </div>
        <div className="col prose mt-14">
          <p>
            I'm Farshid Yaghoubi, and this is a design task I did for ZeroB. The main constraint was simple: the second display is wider, but the UI components need to stay the same
            size. That meant I could not treat the 2880 version as a larger redesign of the 1920 screen.
          </p>
          <p>The extra width needed a clear purpose without creating a second component system.</p>
        </div>
        <div className="mt-14 grid gap-10 border-t border-[var(--ink)] pt-6 lg:grid-cols-[1fr_340px]">
          <div className="col">
            <p className="eyebrow mb-4">In brief</p>
            <p className="text-[21px] leading-[1.45] tracking-[-0.01em]">
              Both screens use one horizontal collection of fixed-size cards beside the same map. The 1920 display shows
              two cards; the 2880 display shows four. Because a visible card can still be too far from the driver, the
              collection stays movable: a fixed selector brings any card next to the map on either width.
            </p>
          </div>
          <div className="grid content-start gap-3">
            <p className="eyebrow">Live demo</p>
            {DEMO_URL ? (
              <a
                href={DEMO_URL}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-between rounded-[6px] bg-[var(--ink)] px-4 py-3 text-[14px] font-medium text-white hover:bg-[#383838]"
              >
                Open the interactive prototype <span aria-hidden>↗</span>
              </a>
            ) : (
              <span className="inline-flex items-center justify-between rounded-[8px] px-4 py-3 text-[14px] shadow-[var(--ring)] text-[var(--muted)]">
                Interactive prototype — link coming soon
              </span>
            )}
            <p className="caption m-0">Works at 1920 and 2880. Try the selector under the map.</p>
          </div>
        </div>
      </header>

      {/* 01 */}
      <Section n="01" label="Constraint" title="Same components, 960 more pixels">
        <div className="indent">
          <div className="diagram max-w-[760px]">
            <WidthDiagram />
          </div>
          <p className="caption max-w-[720px]">
            Both displays are 720 px tall. The map, cards and spacing keep the same pixel dimensions on both. Only the
            width changes.
          </p>
          <p className="statement mt-20 mb-6">
            How can one infotainment Home use an extra 960 px of horizontal space while keeping the same component
            geometry, the same interaction model, and a sensible relationship to the driver?
          </p>
        </div>
      </Section>

      {/* 02 */}
      <Section n="02" label="Scope" title="What I decided not to solve">
        <div className="indent grid gap-12 md:grid-cols-[1fr_1fr]">
          <div>
            <p className="eyebrow mb-4">Outside this concept</p>
            <ul className="dash-list">
              <li>Exact pixel density and physical component size</li>
              <li>Driver eye point and measured reach envelope</li>
              <li>Screen angle, curvature and cockpit packaging</li>
              <li>Localization and RTL layouts</li>
              <li>Complete LHD/RHD adaptation</li>
              <li>Every parked vs driving restriction</li>
              <li>Homologation and certification</li>
              <li>Every vehicle trim or input method</li>
            </ul>
          </div>
          <div className="grid content-start gap-10">
            <div>
              <p className="eyebrow mb-4">Assumptions I kept simple</p>
              <ul className="dash-list">
                <li>Left-hand-drive vehicle</li>
                <li>The display extends to the right</li>
                <li>Essential cluster information lives outside this Home</li>
                <li>The same content and component library exist on both screens</li>
              </ul>
            </div>
            <div>
              <p className="eyebrow mb-4">Carried into every decision</p>
              <p className="small">
                Hierarchy · predictable access · restrained information density · driver-side usability · component
                reuse · a clear reason for using the extra width
              </p>
            </div>
          </div>
        </div>
        <div className="indent col prose mt-10">
          <p>
            Those are real HMI concerns, and they would need real vehicle data. They were not necessary to answer the
            main question, so I separated them from the core problem before designing.
          </p>
        </div>
      </Section>

      {/* 03 */}
      <Section n="03" label="Research" title="Researching structure, not visual inspiration">
        <div className="indent col prose">
          <p>
            I started by looking at production HMIs, but I tried to avoid turning the research into a moodboard. The
            questions were more useful when they were structural:
          </p>
        </div>
        <div className="indent mb-16 max-w-[720px]">
          <ul className="dash-list">
            <li>What stays available when the main content changes?</li>
            <li>Which functions need permanent Home space, and which only need direct access?</li>
            <li>How do navigation and secondary tasks coexist?</li>
            <li>What happens when a display gets wider?</li>
            <li>Does extra width become more content, more context, or a different user zone?</li>
          </ul>
        </div>

        <div className="indent grid gap-16">
          {research.map((r) => (
            <article key={r.name} className="grid gap-8 border-t border-[var(--rule)] pt-8 md:grid-cols-[320px_1fr]">
              <div>
                {r.img ? (
                  <ResearchImage src={r.img} alt={r.caption} />
                ) : (
                  <div className="crop flex aspect-[16/10] items-center justify-center bg-white p-6">
                    <Pattern kind={r.kind} />
                  </div>
                )}
                <p className="caption">{r.caption}</p>
              </div>
              <div className="grid gap-6 md:grid-cols-[1fr_200px]">
                <div>
                  <h3 className="h3">{r.name}</h3>
                  <p className="eyebrow mt-5 mb-1">What I looked at</p>
                  <p className="small">→ {r.looked}</p>
                  <p className="eyebrow mt-5 mb-1">What I took from it</p>
                  <p className="small">→ {r.took}</p>
                </div>
                {r.img && (
                  <div>
                    <p className="eyebrow mb-2">Pattern</p>
                    <Pattern kind={r.kind} />
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>

        <div className="indent mt-20">
          <p className="eyebrow mb-6">What survived into the design — three rules</p>
          <ol className="grid gap-px border-y border-[var(--ink)] bg-[var(--rule)] md:grid-cols-3">
            {[
              ['Persistent access and Home content are different jobs.', 'Climate, Home, Apps and vehicle controls can stay reachable without taking over the main workspace.'],
              ['Extra width should add useful context, not just more pixels between things.', 'Spreading the same controls farther apart is not a meaningful use of a wider display.'],
              ['The system should stay recognizably the same across both widths.', 'One Home architecture, not a narrow version and a separate wide-screen product.'],
            ].map(([h, p], i) => (
              <li key={i} className="list-none bg-[var(--bg)] py-6 md:px-6 md:first:pl-0">
                <span className="section-num">0{i + 1}</span>
                <p className="mt-3 text-[18px] font-semibold leading-snug">{h}</p>
                <p className="small mt-3">{p}</p>
              </li>
            ))}
          </ol>
        </div>
      </Section>

      {/* 04 */}
      <Section n="04" label="Information architecture" title="Defining the Home before solving the width">
        <div className="indent grid gap-14 lg:grid-cols-[1fr_300px]">
          <div className="border-y border-[var(--ink)]">
            {[
              { tier: 'Primary', items: [['Navigation', 'The map stays the main driving context.']], strong: true },
              {
                tier: 'Secondary',
                items: [
                  ['Media', 'High-frequency task; deserves a permanent Home presence.'],
                  ['Journey', 'Broader trip information that should not compete with the maneuver on the map.'],
                ],
              },
              {
                tier: 'Available when needed',
                items: [
                  ['Phone', 'Part of the same collection, but not one of the two default cards.'],
                  ['Ahead', 'Route-adjacent context: upcoming services, arrival.'],
                ],
              },
              { tier: 'Persistent shell', items: [['Climate · Home · Apps', 'Directly accessible without becoming full Home cards.']], shell: true },
            ].map((row) => (
              <div key={row.tier} className="grid gap-4 border-b border-[var(--rule)] py-6 last:border-0 sm:grid-cols-[170px_1fr]">
                <p className="eyebrow pt-1">{row.tier}</p>
                <div className="grid gap-3 sm:grid-cols-2">
                  {row.items.map(([name, desc]) => (
                    <div
                      key={name}
                      className="px-4 py-3"
                      style={{
                        border: row.shell ? '1px dashed var(--rule-strong)' : '1px solid var(--ink)',
                        background: row.strong ? 'var(--fill)' : 'transparent',
                        gridColumn: row.strong || row.shell ? '1 / -1' : undefined,
                      }}
                    >
                      <p className="text-[16px] font-semibold">{name}</p>
                      <p className="mt-1 text-[14px] leading-snug text-[var(--muted)]">{desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="prose">
            <p>Before deciding how the 2880 screen should work, I needed a stable 1920 baseline. I reduced the Home to a few clear roles.</p>
            <p>
              The shell is drawn dashed on purpose. Following the Volkswagen lesson, these functions are important but
              live outside the workspace.
            </p>
            <p>
              <strong>This gave me a fixed content system to test against both widths.</strong> From that point on, the
              width studies were not allowed to invent a different IA just to make the larger screen look better.
            </p>
          </div>
        </div>
      </Section>

      {/* 05 */}
      <Section n="05" label="Baseline" title="Freezing the 1920 geometry">
        <div className="indent">
          <div className="col prose">
            <p>
              I held the 1920 layout still before comparing wide-screen strategies. The component geometry was fixed
              before any width exploration started, so every concept had to work with the same pieces.
            </p>
          </div>
          <div className="diagram mt-6 max-w-[620px]">
            <BaselineDiagram />
          </div>
          <dl className="mt-6 grid max-w-[620px] grid-cols-2 gap-y-2 font-[var(--mono)] text-[13px] sm:grid-cols-4">
            {[['Map', '824 × 544'], ['Home card', '448 × 544'], ['Gap', '32 px'], ['Access rail', '88 × 544']].map(([k, v]) => (
              <div key={k}>
                <dt className="eyebrow">{k}</dt>
                <dd className="m-0 mt-1 text-[15px]">{v}</dd>
              </div>
            ))}
          </dl>
        </div>
      </Section>

      {/* 06 */}
      <Section n="06" label="Exploration" title="Four ways to use the extra width">
        <div className="indent col prose mb-14">
          <p>With the 1920 layout held still, I explored several ways to handle the extra space. Each sketch shows the frozen 1920 layout above and the 2880 proposal below, at the same scale.</p>
        </div>
        <div className="grid gap-20">
          {concepts.map((c) => (
            <article key={c.id} className="grid gap-8 lg:grid-cols-[1fr_300px]">
              <figure className="m-0">
                <div className="diagram"><ConceptSketch kind={c.kind} /></div>
              </figure>
              <div className="pt-2">
                <p className="section-num">{c.id}</p>
                <h3 className="h3 mt-2">{c.title}</h3>
                <span className="tag mt-2 mb-4">{c.verdict}</span>
                <p className="small">{c.text}</p>
              </div>
            </article>
          ))}

          <article className="grid gap-8 border-t-2 border-[var(--accent)] pt-8 lg:grid-cols-[1fr_300px]">
            <figure className="m-0">
              <div className="diagram"><ConceptSketch kind="D" /></div>
            </figure>
            <div className="pt-2">
              <p className="section-num" style={{ color: 'var(--accent)' }}>D</p>
              <h3 className="h3 mt-2">Reveal more of the same card collection</h3>
              <span className="tag tag-accent mt-2 mb-4">Chosen direction</span>
              <p className="small">
                Both displays use one horizontal collection of fixed-size cards. The 1920 version exposes less of it.
                The 2880 version exposes more of it.
              </p>
              <p className="small mt-3">
                The map stays in the same place. The cards keep the same dimensions and spacing. The 2880 version gains
                context without gaining a second feature set.
              </p>
            </div>
          </article>
        </div>

        <div className="mt-24 overflow-x-auto">
          <div className="mb-5 flex flex-wrap items-baseline justify-between gap-3">
            <p className="eyebrow">Comparison of the four directions</p>
            <p className="caption m-0">Qualitative judgement from the explorations, not measured or user-tested.</p>
          </div>
          <table className="matrix min-w-[760px]">
            <thead>
              <tr>
                <th>Direction</th>
                {matrixCols.map((c) => <th key={c}>{c}</th>)}
              </tr>
            </thead>
            <tbody>
              {matrix.map((r) => (
                <tr key={r.name} className={r.chosen ? 'chosen' : ''}>
                  <td className="font-semibold">{r.name}</td>
                  {r.marks.map((m, i) => <td key={i}><MarkCell m={m} /></td>)}
                </tr>
              ))}
            </tbody>
          </table>
          <p className="caption">
            For “new layout logic” and “reach concern”, fewer dots is better. D still carries a reach concern, which
            sections 08 and 09 deal with.
          </p>
        </div>
      </Section>

      {/* 07 */}
      <Section n="07" label="Decision" title="One collection, two windows">
        <div className="indent grid gap-10 lg:grid-cols-[1fr_260px]">
          <div className="diagram">
            <SystemDiagram />
          </div>
          <div className="grid content-start gap-7 text-[15px]">
            <div>
              <p className="eyebrow mb-2">1920</p>
              <p>Same map · 2 visible cards</p>
            </div>
            <div>
              <p className="eyebrow mb-2">2880</p>
              <p>Same map · 4 visible cards</p>
            </div>
            <div className="border-t border-[var(--rule)] pt-5">
              <p className="eyebrow mb-2">Shared</p>
              <p className="leading-relaxed">Card dimensions<br />Card spacing<br />Content collection<br />Interaction model</p>
            </div>
          </div>
        </div>
        <div className="indent col prose mt-12">
          <p>
            <strong>1920 = smaller window into the same system. 2880 = wider window into the same system.</strong> This
            is where the reuse argument became concrete. The wider display is not a different composition with
            similar-looking components. It is the same map, the same card family, the same spacing and the same content
            collection, with a larger visible area.
          </p>
        </div>
        <div className="mt-14 grid gap-10">
          <Shot src={final1920} alt="Final 1920 × 720 Home" caption={<><b>1920 × 720.</b> Map, Media and Journey. The selector under the map lists the full collection.</>} />
          <Shot src={final2880} alt="Final 2880 × 720 Home" caption={<><b>2880 × 720.</b> The same map and cards; Phone and Ahead are now visible too.</>} />
        </div>
      </Section>

      {/* 08 */}
      <Section n="08" label="Second problem" title="Visibility created an access question">
        <div className="indent">
          <p className="quote max-w-[18ch]">More visible did not mean more reachable.</p>
          <div className="col prose mt-10">
            <p>
              Once all four cards could be visible on the wider screen, another problem became obvious. A card can be
              visible and still be too far away to be a good driver interaction target.
            </p>
            <p>If the far cards stay static, the 2880 solution solves visibility but can make access worse.</p>
          </div>
          <div className="diagram mt-8">
            <ReachDiagram />
          </div>
          <p className="caption max-w-[720px]">
            The boundary is drawn at the 1920 edge only to illustrate the idea. The real comfortable interaction
            boundary depends on vehicle geometry I did not have.
          </p>
        </div>
      </Section>

      {/* 09 */}
      <Section n="09" label="Interaction" title="Bringing content nearer">
        <div className="indent grid gap-12 lg:grid-cols-[1fr_1fr]">
          <div className="prose">
            <p>So I kept the card collection movable on both displays.</p>
            <ul className="dash-list mb-6">
              <li>Media and Journey are the default cards nearest to the map</li>
              <li>Phone and Ahead remain part of the same collection</li>
              <li>Swiping moves the collection</li>
              <li>A fixed selector lets the driver bring any card to the near side</li>
              <li>The same interaction works at 1920 and 2880</li>
            </ul>
          </div>
          <div className="prose">
            <p><strong>On the narrow display,</strong> it reveals content that is currently off-screen.</p>
            <p><strong>On the wide display,</strong> it can bring a farther card back toward the driver.</p>
            <p>The wider display gives more visible information, but it does not ask the driver to treat all 2880 pixels as an equally comfortable touch area.</p>
          </div>
        </div>
        <div className="mt-12">
          <MoveFrames />
        </div>
        <div className="indent hypo mt-10 max-w-[720px]">
          <b>Design hypothesis — not validated</b>
          Moving cards means their screen position is not permanently fixed. I would want to test whether the benefit
          of bringing content closer is worth the re-orientation cost. Without real vehicle geometry and user testing,
          this remains an informed design hypothesis, not an ergonomic claim.
        </div>
      </Section>

      {/* 10 */}
      <Section n="10" label="Content logic" title="Why Media and Journey sit first">
        <div className="indent grid gap-px border-y border-[var(--ink)] bg-[var(--rule)] sm:grid-cols-2 lg:grid-cols-4">
          {[
            ['Map', 'The immediate driving situation.'],
            ['Media · default', 'Frequent secondary task. Glanceable: current track, playback state, basic controls. Does not duplicate the map.'],
            ['Journey · default', 'Wider trip context: destination, ETA, route state, route overview. Keeps the map focused.'],
            ['Phone · Ahead', 'Phone stays available without a default position. Ahead adds driving-relevant support like upcoming services.'],
          ].map(([h, p]) => (
            <div key={h} className="bg-[var(--bg)] p-5">
              <p className="text-[16px] font-semibold">{h}</p>
              <p className="mt-2 text-[14px] leading-snug text-[var(--ink-2)]">{p}</p>
            </div>
          ))}
        </div>
        <div className="indent col prose mt-8">
          <p>The extra visible cards are not there just to make the 2880 screen look full. Each one needs a clear reason to exist while driving.</p>
        </div>
      </Section>

      {/* 11 */}
      <Section n="11" label="Depth" title="One reusable detail panel">
        <div className="indent grid items-start gap-12 lg:grid-cols-[1fr_1fr]">
          <div className="prose">
            <p>I also wanted opening a card to avoid creating another screen-size problem. Instead of giving every domain a custom full-screen page, deeper content opens in one reusable 448 × 544 detail panel.</p>
            <p>The map and the rest of Home stay available. Closing the detail returns the card. No separate full-screen detail layouts are needed for the two widths.</p>
          </div>
          <div className="grid grid-cols-[140px_auto_1fr] items-center gap-x-5 gap-y-3 font-[var(--mono)] text-[13px]">
            <div className="row-span-6 flex aspect-[448/544] items-center justify-center border border-[var(--ink)] text-center text-[11px] uppercase tracking-wider">
              448 × 544<br />detail panel
            </div>
            {[
              ['Media', 'Queue'],
              ['Phone', 'Device settings'],
              ['Journey', 'Route overview'],
              ['Journey', 'Route conditions'],
              ['Apps', 'Applications'],
              ['Vehicle', 'Comfort'],
            ].map(([a, b], i) => (
              <div key={i} className="contents">
                <span className="text-[var(--muted)]">←</span>
                <span className="border-b border-[var(--rule)] pb-2">{a} → {b}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* 12 */}
      <Section n="12" label="Result" title="Final proposal">
        <LiveDemo />
        <div className="indent mt-14 grid gap-12 md:grid-cols-2">
          <div>
            <p className="eyebrow mb-4">Same on both</p>
            <ul className="dash-list">
              <li>Component dimensions</li>
              <li>Map position, access rail and driver-side controls</li>
              <li>Card system and content collection</li>
              <li>Interaction model: swipe and selector</li>
            </ul>
          </div>
          <div>
            <p className="eyebrow mb-4">Changes</p>
            <ul className="dash-list">
              <li>Amount of visible content: 2 cards → 4 cards</li>
              <li>Passenger-side anchor at the outer boundary</li>
            </ul>
          </div>
        </div>
      </Section>

      {/* 13 */}
      <Section n="13" label="Closing" title="One Home, one adaptation rule">
        <div className="indent col prose">
          <p>The final result is not two independently designed screens. The wider display does not get a separate UI. It gets:</p>
        </div>
        <div className="indent mt-6 grid max-w-[900px] gap-px border-y border-[var(--ink)] bg-[var(--rule)] md:grid-cols-3">
          {['More visible context', 'The same component system', 'A way to bring content closer when width creates an access problem'].map((t) => (
            <p key={t} className="m-0 bg-[var(--bg)] py-6 text-[20px] leading-snug font-semibold tracking-tight md:px-6 md:first:pl-0">{t}</p>
          ))}
        </div>
        <div className="indent col prose mt-12">
          <p>
            Keep the driver-side core stable, keep the components fixed, use the wider display to reveal more context,
            and let the content move toward the driver when access becomes the problem.
          </p>
        </div>
      </Section>

      {zoom && (
        <div className="lightbox" onClick={() => setZoom(null)} role="dialog" aria-label={zoom.alt}>
          <img src={zoom.src} alt={zoom.alt} />
        </div>
      )}
    </main>
  )
}
